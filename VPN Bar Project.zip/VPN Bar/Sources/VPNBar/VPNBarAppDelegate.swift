import AppKit
import Combine
import SwiftUI

@MainActor
final class VPNBarAppDelegate: NSObject, NSApplicationDelegate {
    private let model = VPNController()
    private let popover = NSPopover()
    private var statusItem: NSStatusItem?
    private var iconTimer: Timer?
    private var cancellables = Set<AnyCancellable>()
    private var rotationDegrees: CGFloat = 0

    func applicationDidFinishLaunching(_ notification: Notification) {
        let item = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
        statusItem = item

        if let button = item.button {
            button.target = self
            button.action = #selector(statusItemClicked(_:))
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
            button.imagePosition = .imageOnly
            button.imageScaling = .scaleProportionallyDown
        }

        popover.behavior = .transient
        popover.animates = true
        popover.contentViewController = NSHostingController(
            rootView: VPNPopoverView(model: model) {
                NSApp.terminate(nil)
            }
        )

        NotificationCenter.default.addObserver(
            self,
            selector: #selector(systemColorsDidChange(_:)),
            name: NSColor.systemColorsDidChangeNotification,
            object: nil
        )

        model.objectWillChange
            .sink { [weak self] in
                DispatchQueue.main.async {
                    self?.updateStatusIcon()
                }
            }
            .store(in: &cancellables)

        updateStatusIcon()
        iconTimer = Timer.scheduledTimer(withTimeInterval: 0.11, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                guard let self, self.model.quickState.isTransitioning else { return }
                self.rotationDegrees = (self.rotationDegrees + 34).truncatingRemainder(dividingBy: 360)
                self.updateStatusIcon()
            }
        }
    }

    @objc
    private func statusItemClicked(_ sender: NSStatusBarButton) {
        let isSecondaryClick = NSApp.currentEvent?.type == .rightMouseUp
        if isSecondaryClick {
            togglePopover(from: sender)
        } else {
            model.quickToggle()
            updateStatusIcon()
        }
    }

    private func togglePopover(from button: NSStatusBarButton) {
        if popover.isShown {
            popover.performClose(nil)
        } else {
            popover.show(relativeTo: button.bounds, of: button, preferredEdge: .minY)
        }
    }

    @objc
    private func systemColorsDidChange(_ notification: Notification) {
        updateStatusIcon()
    }

    private func updateStatusIcon() {
        guard let button = statusItem?.button else { return }
        let state = model.quickState
        let icon = model.selectedIcon
        let tint = state.iconColor
        let phase = rotationDegrees
        let imageSize = NSSize(width: 20, height: 20)
        let glyphRenderer = ImageRenderer(
            content: VPNGlyph(icon: icon, size: 18, state: state)
                .frame(width: imageSize.width, height: imageSize.height)
        )
        glyphRenderer.scale = 2
        let glyphImage = glyphRenderer.nsImage
        let image = NSImage(size: imageSize, flipped: false) { rect in
            glyphImage?.draw(in: rect)

            if state.isTransitioning {
                tint.setStroke()
                let ring = NSBezierPath()
                ring.lineWidth = 1.4
                ring.lineCapStyle = .round
                ring.appendArc(
                    withCenter: NSPoint(x: rect.midX, y: rect.midY),
                    radius: 8.8,
                    startAngle: phase,
                    endAngle: phase + 215,
                    clockwise: false
                )
                ring.stroke()
            }
            return true
        }
        image.isTemplate = false
        button.image = image
        button.contentTintColor = nil
        button.setAccessibilityLabel(L10n.format("app.accessibility", state.title))
        button.toolTip = L10n.format("app.tooltip", state.title)
    }
}
