import Foundation

enum L10n {
    private static let language: String = {
        let preferredLanguage = Locale.preferredLanguages.first?.lowercased() ?? "en"
        return preferredLanguage == "ru" || preferredLanguage.hasPrefix("ru-") || preferredLanguage.hasPrefix("ru_")
            ? "ru"
            : "en"
    }()

    private static let bundle: Bundle = {
        guard let path = Bundle.main.path(forResource: language, ofType: "lproj"),
              let localizedBundle = Bundle(path: path) else {
            return .main
        }
        return localizedBundle
    }()

    static func text(_ key: String) -> String {
        bundle.localizedString(forKey: key, value: key, table: "Localizable")
    }

    static func format(_ key: String, _ arguments: CVarArg...) -> String {
        String(format: text(key), locale: Locale(identifier: language), arguments: arguments)
    }
}
