import AppKit
import Combine
import Foundation
import Network
import ServiceManagement

@MainActor
final class VPNController: ObservableObject {
    @Published private(set) var services: [VPNService] = []
    @Published private(set) var isWorking = false
    @Published private(set) var message: String?
    @Published private var transitions: [String: Transition] = [:]
    @Published var showingIconPicker = false
    @Published var showingSettings = false

    @Published var launchAtLoginEnabled: Bool {
        didSet {
            if oldValue != launchAtLoginEnabled {
                updateLaunchAtLogin()
            }
        }
    }

    @Published var automaticReconnectEnabled: Bool {
        didSet {
            UserDefaults.standard.set(automaticReconnectEnabled, forKey: Self.reconnectPreferenceKey)
        }
    }

    @Published var autoConnectOnWiFiEnabled: Bool {
        didSet {
            UserDefaults.standard.set(autoConnectOnWiFiEnabled, forKey: Self.wifiPreferenceKey)
        }
    }

    @Published var selectedIcon: VPNBarIcon {
        didSet {
            UserDefaults.standard.set(selectedIcon.rawValue, forKey: Self.iconPreferenceKey)
        }
    }

    @Published var selectedServiceID: String? {
        didSet {
            if let selectedServiceID {
                UserDefaults.standard.set(selectedServiceID, forKey: Self.servicePreferenceKey)
            } else {
                UserDefaults.standard.removeObject(forKey: Self.servicePreferenceKey)
            }
        }
    }

    private static let iconPreferenceKey = "VPNBar.selectedIcon.v2"
    private static let servicePreferenceKey = "VPNBar.selectedServiceID"
    private static let reconnectPreferenceKey = "VPNBar.automaticReconnect"
    private static let wifiPreferenceKey = "VPNBar.autoConnectOnWiFi"
    private let commandQueue = DispatchQueue(label: "VPNBar.scutil", qos: .userInitiated)
    private let networkQueue = DispatchQueue(label: "VPNBar.network", qos: .utility)
    private let networkMonitor = NWPathMonitor()
    private var refreshTimer: Timer?
    private var wakeObserver: NSObjectProtocol?
    private var previousPathAvailable: Bool?
    private var isWiFiConnected = false
    private var suppressedReconnectIDs = Set<String>()
    private var autoConnectWorkItem: DispatchWorkItem?
    private var lastAutomaticConnectAttempt: Date?

    private struct Transition {
        let state: VPNConnectionState
        let startedAt: Date
    }

    init() {
        let storedIcon = UserDefaults.standard.string(forKey: Self.iconPreferenceKey)
        selectedIcon = storedIcon.flatMap(VPNBarIcon.init(rawValue:)) ?? .openLock
        selectedServiceID = UserDefaults.standard.string(forKey: Self.servicePreferenceKey)
        launchAtLoginEnabled = Self.isLaunchAtLoginEnabled
        automaticReconnectEnabled = UserDefaults.standard.bool(forKey: Self.reconnectPreferenceKey)
        autoConnectOnWiFiEnabled = UserDefaults.standard.bool(forKey: Self.wifiPreferenceKey)

        networkMonitor.pathUpdateHandler = { [weak self] path in
            Task { @MainActor [weak self] in
                self?.handleNetworkPathUpdate(path)
            }
        }
        networkMonitor.start(queue: networkQueue)

        wakeObserver = NSWorkspace.shared.notificationCenter.addObserver(
            forName: NSWorkspace.didWakeNotification,
            object: nil,
            queue: .main
        ) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.handleWake()
            }
        }

        refresh()
        refreshTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.refresh()
            }
        }
    }

    var quickService: VPNService? {
        if let selectedServiceID,
           let selected = services.first(where: { $0.id == selectedServiceID }),
           state(for: selected).isTransitioning {
            return selected
        }
        if let connected = services.first(where: \.isConnected) {
            return connected
        }
        if let selectedServiceID, let selected = services.first(where: { $0.id == selectedServiceID }) {
            return selected
        }
        return services.first
    }

    var quickState: VPNConnectionState {
        guard let service = quickService else { return .disconnected }
        return state(for: service)
    }

    func state(for service: VPNService) -> VPNConnectionState {
        if let transition = transitions[service.id] {
            return transition.state
        }
        return service.isConnected ? .connected : .disconnected
    }

    func refresh() {
        commandQueue.async { [weak self] in
            let result: Result<[VPNService], Error>
            do {
                let output = try Self.runScutil(["--nc", "list"])
                result = .success(Self.parseServices(from: output))
            } catch {
                result = .failure(error)
            }

            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case let .success(foundServices):
                    let previouslyConnectedIDs = Set(self.services.filter(\.isConnected).map(\.id))
                    let currentlyConnectedIDs = Set(foundServices.filter(\.isConnected).map(\.id))
                    self.services = foundServices
                    self.reconcileTransitions()
                    if self.selectedServiceID == nil || !foundServices.contains(where: { $0.id == self.selectedServiceID }) {
                        self.selectedServiceID = foundServices.first(where: \.isConnected)?.id ?? foundServices.first?.id
                    }
                    if foundServices.isEmpty {
                        self.message = L10n.text("vpn.none.message")
                    } else if self.message == L10n.text("vpn.none.message") {
                        self.message = nil
                    }
                    for serviceID in previouslyConnectedIDs.subtracting(currentlyConnectedIDs) {
                        if self.suppressedReconnectIDs.remove(serviceID) == nil,
                           self.automaticReconnectEnabled {
                            self.scheduleAutomaticConnect()
                        }
                    }
                case .failure:
                    self.message = L10n.text("error.readVPN")
                }
            }
        }
    }

    func quickToggle() {
        guard let service = quickService else {
            message = L10n.text("vpn.add.message")
            return
        }
        toggle(service)
    }

    func selectAndConnect(_ service: VPNService) {
        selectedServiceID = service.id
        guard state(for: service) != .connected else { return }
        connect(service)
    }

    func toggle(_ service: VPNService) {
        selectedServiceID = service.id
        switch state(for: service) {
        case .connected:
            disconnect(service)
        case .disconnected:
            connect(service)
        case .connecting, .disconnecting:
            break
        }
    }

    func clearMessage() {
        message = nil
    }

    private static var isLaunchAtLoginEnabled: Bool {
        let status = SMAppService.mainApp.status
        return status == .enabled || status == .requiresApproval
    }

    private func updateLaunchAtLogin() {
        do {
            if launchAtLoginEnabled {
                try SMAppService.mainApp.register()
            } else {
                try SMAppService.mainApp.unregister()
            }

            let status = SMAppService.mainApp.status
            launchAtLoginEnabled = status == .enabled || status == .requiresApproval
            if status == .requiresApproval {
                message = L10n.text("settings.loginApproval")
            }
        } catch {
            launchAtLoginEnabled = Self.isLaunchAtLoginEnabled
            message = L10n.text("settings.loginFailure")
        }
    }

    private func handleWake() {
        guard automaticReconnectEnabled else { return }
        scheduleAutomaticConnect(after: 2)
    }

    private func handleNetworkPathUpdate(_ path: NWPath) {
        let isAvailable = path.status == .satisfied
        let usesWiFi = isAvailable && path.usesInterfaceType(.wifi)

        guard let wasAvailable = previousPathAvailable else {
            previousPathAvailable = isAvailable
            isWiFiConnected = usesWiFi
            if usesWiFi && autoConnectOnWiFiEnabled {
                scheduleAutomaticConnect(after: 2)
            }
            return
        }

        let wasWiFiConnected = isWiFiConnected
        previousPathAvailable = isAvailable
        isWiFiConnected = usesWiFi
        guard isAvailable else { return }

        let networkReturned = !wasAvailable
        let joinedWiFi = usesWiFi && !wasWiFiConnected
        if (automaticReconnectEnabled && networkReturned)
            || (autoConnectOnWiFiEnabled && usesWiFi && (joinedWiFi || networkReturned)) {
            scheduleAutomaticConnect(after: 2)
        }
    }

    private func scheduleAutomaticConnect(after delay: TimeInterval = 1.5) {
        guard automaticReconnectEnabled || autoConnectOnWiFiEnabled else { return }
        if let lastAutomaticConnectAttempt,
           Date().timeIntervalSince(lastAutomaticConnectAttempt) < 6 {
            return
        }

        autoConnectWorkItem?.cancel()
        let workItem = DispatchWorkItem { [weak self] in
            Task { @MainActor [weak self] in
                guard let self else { return }
                self.autoConnectWorkItem = nil
                self.connectSelectedServiceIfNeeded()
            }
        }
        autoConnectWorkItem = workItem
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: workItem)
    }

    private func connectSelectedServiceIfNeeded() {
        guard !isWorking,
              let service = services.first(where: { $0.id == selectedServiceID }) ?? services.first,
              !suppressedReconnectIDs.contains(service.id),
              state(for: service) == .disconnected else {
            return
        }

        lastAutomaticConnectAttempt = Date()
        connect(service)
    }

    private func cancelScheduledAutomaticConnect() {
        autoConnectWorkItem?.cancel()
        autoConnectWorkItem = nil
    }

    private func connect(_ service: VPNService) {
        guard !isWorking else { return }
        cancelScheduledAutomaticConnect()
        suppressedReconnectIDs.remove(service.id)
        isWorking = true
        message = nil
        transitions[service.id] = Transition(state: .connecting, startedAt: Date())
        let otherConnectedIDs = services.filter { $0.id != service.id && $0.isConnected }.map(\.id)
        suppressedReconnectIDs.formUnion(otherConnectedIDs)

        commandQueue.async { [weak self] in
            do {
                for otherID in otherConnectedIDs {
                    _ = try Self.runScutil(["--nc", "stop", otherID])
                }
                _ = try Self.runScutil(["--nc", "select", service.id])
                _ = try Self.runScutil(["--nc", "start", service.id])
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.refresh()
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.transitions.removeValue(forKey: service.id)
                    self?.suppressedReconnectIDs.subtract(otherConnectedIDs)
                    self?.message = L10n.text("error.command")
                    self?.refresh()
                }
            }
        }
    }

    private func disconnect(_ service: VPNService) {
        guard !isWorking else { return }
        cancelScheduledAutomaticConnect()
        suppressedReconnectIDs.insert(service.id)
        isWorking = true
        message = nil
        transitions[service.id] = Transition(state: .disconnecting, startedAt: Date())

        commandQueue.async { [weak self] in
            do {
                _ = try Self.runScutil(["--nc", "stop", service.id])
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.refresh()
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.transitions.removeValue(forKey: service.id)
                    self?.suppressedReconnectIDs.remove(service.id)
                    self?.message = L10n.text("error.command")
                    self?.refresh()
                }
            }
        }
    }

    private func reconcileTransitions() {
        let now = Date()
        var finishedTransitions: [String] = []
        var timedOut = false
        for (serviceID, transition) in transitions {
            let isConnected = services.first(where: { $0.id == serviceID })?.isConnected ?? false
            if (transition.state == .connecting && isConnected) || (transition.state == .disconnecting && !isConnected) {
                finishedTransitions.append(serviceID)
            } else if now.timeIntervalSince(transition.startedAt) > 30 {
                finishedTransitions.append(serviceID)
                timedOut = true
            }
        }
        for serviceID in finishedTransitions {
            transitions.removeValue(forKey: serviceID)
        }
        if timedOut {
            message = L10n.text("error.connectionTimeout")
        }
    }

    nonisolated private static func parseServices(from output: String) -> [VPNService] {
        let pattern = #"^\s*\*?\s*\(([^)]+)\)\s+([0-9A-Fa-f-]{36}).*?"([^"]+)"\s+\[VPN:([^\]]+)\]"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }

        let parsed = output.components(separatedBy: .newlines).compactMap { line -> VPNService? in
            let nsLine = line as NSString
            let range = NSRange(location: 0, length: nsLine.length)
            guard let match = regex.firstMatch(in: line, range: range), match.numberOfRanges == 5 else {
                return nil
            }

            func capture(_ index: Int) -> String {
                let range = match.range(at: index)
                guard range.location != NSNotFound else { return "" }
                return nsLine.substring(with: range)
            }

            let rawState = capture(1).lowercased()
            return VPNService(
                id: capture(2),
                name: capture(3),
                provider: capture(4),
                isConnected: rawState.hasPrefix("connected")
            )
        }

        return parsed.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    nonisolated private static func runScutil(_ arguments: [String]) throws -> String {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/sbin/scutil")
        process.arguments = arguments
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
        } catch {
            throw NSError(domain: "VPNBar.scutil", code: 1, userInfo: [
                NSLocalizedDescriptionKey: L10n.text("error.scutil.launch")
            ])
        }

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        let output = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)

        guard process.terminationStatus == 0 else {
            throw NSError(domain: "VPNBar.scutil", code: Int(process.terminationStatus), userInfo: [
                NSLocalizedDescriptionKey: output.isEmpty ? L10n.text("error.command") : output
            ])
        }
        return output
    }
}
