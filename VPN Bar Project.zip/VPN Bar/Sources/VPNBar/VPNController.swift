import Combine
import Foundation

@MainActor
final class VPNController: ObservableObject {
    @Published private(set) var services: [VPNService] = []
    @Published private(set) var isWorking = false
    @Published private(set) var message: String?
    @Published private var transitions: [String: Transition] = [:]
    @Published var showingIconPicker = false

    @Published var selectedIcon: VPNBarIcon {
        didSet {
            UserDefaults.standard.set(selectedIcon.rawValue, forKey: Self.iconPreferenceKey)
        }
    }

    @Published var selectedServiceID: String? {
        didSet {
            if let selectedServiceID {
                UserDefaults.standard.set(selectedServiceID, forKey: Self.servicePreferenceKey)
            } else {
                UserDefaults.standard.removeObject(forKey: Self.servicePreferenceKey)
            }
        }
    }

    private static let iconPreferenceKey = "VPNBar.selectedIcon.v2"
    private static let servicePreferenceKey = "VPNBar.selectedServiceID"
    private let commandQueue = DispatchQueue(label: "VPNBar.scutil", qos: .userInitiated)
    private var refreshTimer: Timer?

    private struct Transition {
        let state: VPNConnectionState
        let startedAt: Date
    }

    init() {
        let storedIcon = UserDefaults.standard.string(forKey: Self.iconPreferenceKey)
        selectedIcon = storedIcon.flatMap(VPNBarIcon.init(rawValue:)) ?? .openLock
        selectedServiceID = UserDefaults.standard.string(forKey: Self.servicePreferenceKey)

        refresh()
        refreshTimer = Timer.scheduledTimer(withTimeInterval: 2.0, repeats: true) { [weak self] _ in
            Task { @MainActor [weak self] in
                self?.refresh()
            }
        }
    }

    var quickService: VPNService? {
        if let selectedServiceID,
           let selected = services.first(where: { $0.id == selectedServiceID }),
           state(for: selected).isTransitioning {
            return selected
        }
        if let connected = services.first(where: \.isConnected) {
            return connected
        }
        if let selectedServiceID, let selected = services.first(where: { $0.id == selectedServiceID }) {
            return selected
        }
        return services.first
    }

    var quickState: VPNConnectionState {
        guard let service = quickService else { return .disconnected }
        return state(for: service)
    }

    func state(for service: VPNService) -> VPNConnectionState {
        if let transition = transitions[service.id] {
            return transition.state
        }
        return service.isConnected ? .connected : .disconnected
    }

    func refresh() {
        commandQueue.async { [weak self] in
            let result: Result<[VPNService], Error>
            do {
                let output = try Self.runScutil(["--nc", "list"])
                result = .success(Self.parseServices(from: output))
            } catch {
                result = .failure(error)
            }

            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case let .success(foundServices):
                    self.services = foundServices
                    self.reconcileTransitions()
                    if self.selectedServiceID == nil || !foundServices.contains(where: { $0.id == self.selectedServiceID }) {
                        self.selectedServiceID = foundServices.first(where: \.isConnected)?.id ?? foundServices.first?.id
                    }
                    if foundServices.isEmpty {
                        self.message = "VPN-подключения macOS не найдены."
                    } else if self.message == "VPN-подключения macOS не найдены." {
                        self.message = nil
                    }
                case let .failure(error):
                    self.message = "Не удалось прочитать список VPN: \(error.localizedDescription)"
                }
            }
        }
    }

    func quickToggle() {
        guard let service = quickService else {
            message = "Добавьте VPN в настройках macOS → VPN."
            return
        }
        toggle(service)
    }

    func selectAndConnect(_ service: VPNService) {
        selectedServiceID = service.id
        guard state(for: service) != .connected else { return }
        connect(service)
    }

    func toggle(_ service: VPNService) {
        selectedServiceID = service.id
        switch state(for: service) {
        case .connected:
            disconnect(service)
        case .disconnected:
            connect(service)
        case .connecting, .disconnecting:
            break
        }
    }

    func clearMessage() {
        message = nil
    }

    private func connect(_ service: VPNService) {
        guard !isWorking else { return }
        isWorking = true
        message = nil
        transitions[service.id] = Transition(state: .connecting, startedAt: Date())
        let otherConnectedIDs = services.filter { $0.id != service.id && $0.isConnected }.map(\.id)

        commandQueue.async { [weak self] in
            do {
                for otherID in otherConnectedIDs {
                    _ = try Self.runScutil(["--nc", "stop", otherID])
                }
                _ = try Self.runScutil(["--nc", "select", service.id])
                _ = try Self.runScutil(["--nc", "start", service.id])
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.refresh()
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.transitions.removeValue(forKey: service.id)
                    self?.message = error.localizedDescription
                    self?.refresh()
                }
            }
        }
    }

    private func disconnect(_ service: VPNService) {
        guard !isWorking else { return }
        isWorking = true
        message = nil
        transitions[service.id] = Transition(state: .disconnecting, startedAt: Date())

        commandQueue.async { [weak self] in
            do {
                _ = try Self.runScutil(["--nc", "stop", service.id])
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.refresh()
                }
            } catch {
                DispatchQueue.main.async {
                    self?.isWorking = false
                    self?.transitions.removeValue(forKey: service.id)
                    self?.message = error.localizedDescription
                    self?.refresh()
                }
            }
        }
    }

    private func reconcileTransitions() {
        let now = Date()
        var finishedTransitions: [String] = []
        var timedOut = false
        for (serviceID, transition) in transitions {
            let isConnected = services.first(where: { $0.id == serviceID })?.isConnected ?? false
            if (transition.state == .connecting && isConnected) || (transition.state == .disconnecting && !isConnected) {
                finishedTransitions.append(serviceID)
            } else if now.timeIntervalSince(transition.startedAt) > 30 {
                finishedTransitions.append(serviceID)
                timedOut = true
            }
        }
        for serviceID in finishedTransitions {
            transitions.removeValue(forKey: serviceID)
        }
        if timedOut {
            message = "Подключение не завершилось. Проверьте настройки VPN."
        }
    }

    nonisolated private static func parseServices(from output: String) -> [VPNService] {
        let pattern = #"^\s*\*?\s*\(([^)]+)\)\s+([0-9A-Fa-f-]{36}).*?"([^"]+)"\s+\[VPN:([^\]]+)\]"#
        guard let regex = try? NSRegularExpression(pattern: pattern) else { return [] }

        let parsed = output.components(separatedBy: .newlines).compactMap { line -> VPNService? in
            let nsLine = line as NSString
            let range = NSRange(location: 0, length: nsLine.length)
            guard let match = regex.firstMatch(in: line, range: range), match.numberOfRanges == 5 else {
                return nil
            }

            func capture(_ index: Int) -> String {
                let range = match.range(at: index)
                guard range.location != NSNotFound else { return "" }
                return nsLine.substring(with: range)
            }

            let rawState = capture(1).lowercased()
            return VPNService(
                id: capture(2),
                name: capture(3),
                provider: capture(4),
                isConnected: rawState.hasPrefix("connected")
            )
        }

        return parsed.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
    }

    nonisolated private static func runScutil(_ arguments: [String]) throws -> String {
        let process = Process()
        process.executableURL = URL(fileURLWithPath: "/usr/sbin/scutil")
        process.arguments = arguments
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
        } catch {
            throw NSError(domain: "VPNBar.scutil", code: 1, userInfo: [
                NSLocalizedDescriptionKey: "Не удалось запустить scutil: \(error.localizedDescription)"
            ])
        }

        let data = pipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        let output = String(decoding: data, as: UTF8.self).trimmingCharacters(in: .whitespacesAndNewlines)

        guard process.terminationStatus == 0 else {
            throw NSError(domain: "VPNBar.scutil", code: Int(process.terminationStatus), userInfo: [
                NSLocalizedDescriptionKey: output.isEmpty ? "Команда VPN завершилась с ошибкой." : output
            ])
        }
        return output
    }
}
