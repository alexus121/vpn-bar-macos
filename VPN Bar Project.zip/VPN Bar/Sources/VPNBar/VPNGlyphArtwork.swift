import AppKit
import SwiftUI

struct VPNGlyph: View {
    let icon: VPNBarIcon
    let size: CGFloat
    let state: VPNConnectionState
    var tintOverride: Color? = nil

    private var tint: Color {
        tintOverride ?? Color(nsColor: state.iconColor)
    }

    var body: some View {
        Group {
            if let image = icon.image(for: state) {
                Image(nsImage: image)
                    .renderingMode(icon == .monkey ? .original : .template)
                    .resizable()
                    .interpolation(.high)
                    .aspectRatio(contentMode: .fit)
                    .foregroundStyle(tint)
            } else {
                Color.clear
            }
        }
        .frame(width: size, height: size)
        .accessibilityHidden(true)
    }
}
