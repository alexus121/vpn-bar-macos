import AppKit

@main
struct VPNBarMain {
    @MainActor
    static func main() {
        let application = NSApplication.shared
        application.setActivationPolicy(.accessory)
        let delegate = VPNBarAppDelegate()
        application.delegate = delegate
        application.run()
    }
}
