import AppKit
import Foundation

struct VPNService: Identifiable, Equatable {
    let id: String
    let name: String
    let provider: String
    var isConnected: Bool
}

enum VPNConnectionState: Equatable {
    case disconnected
    case connecting
    case connected
    case disconnecting

    var title: String {
        switch self {
        case .disconnected: L10n.text("status.disconnected")
        case .connecting: L10n.text("status.connecting")
        case .connected: L10n.text("status.connected")
        case .disconnecting: L10n.text("status.disconnecting")
        }
    }

    var isTransitioning: Bool {
        self == .connecting || self == .disconnecting
    }

    var usesConnectedAppearance: Bool {
        self == .connected || self == .connecting
    }

    var statusColor: NSColor {
        if usesConnectedAppearance {
            NSColor.controlAccentColor
        } else {
            NSColor.secondaryLabelColor
        }
    }

    var iconColor: NSColor {
        usesConnectedAppearance
            ? NSColor.controlAccentColor
            : NSColor.white
    }
}

enum VPNBarIcon: String, CaseIterable, Identifiable {
    case eye
    case vpn
    case lightning
    case openLock
    case globe
    case key
    case monkey

    var id: String { rawValue }

    var title: String {
        switch self {
        case .eye: L10n.text("icon.eye")
        case .vpn: L10n.text("icon.vpn")
        case .lightning: L10n.text("icon.lightning")
        case .openLock: L10n.text("icon.lock")
        case .globe: L10n.text("icon.globe")
        case .key: L10n.text("icon.key")
        case .monkey: L10n.text("icon.monkey")
        }
    }

    private var assetName: String? {
        switch self {
        case .eye: "icon-eye"
        case .vpn: "icon-vpn"
        case .lightning: "icon-lightning"
        case .openLock: "icon-open-lock"
        case .globe: "icon-globe"
        case .key: "icon-key"
        case .monkey: nil
        }
    }

    private func stateAssetName(for state: VPNConnectionState) -> String {
        state.usesConnectedAppearance ? "monkey-connected" : "monkey-disconnected"
    }

    func image(for state: VPNConnectionState) -> NSImage? {
        let isMonkey = self == .monkey
        let name: String
        if isMonkey {
            name = stateAssetName(for: state)
        } else if let assetName {
            name = assetName
        } else {
            return nil
        }
        guard let url = Bundle.main.url(forResource: name, withExtension: "png") else { return nil }
        let image = NSImage(contentsOf: url)
        image?.isTemplate = !isMonkey
        return image
    }
}
