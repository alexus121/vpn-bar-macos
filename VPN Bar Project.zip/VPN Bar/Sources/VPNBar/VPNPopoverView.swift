import SwiftUI

struct VPNPopoverView: View {
    @ObservedObject var model: VPNController
    let onQuit: () -> Void

    private var statusColor: Color {
        Color(nsColor: model.quickState.statusColor)
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            header

            if model.services.isEmpty {
                emptyState
            } else {
                quickControl
                if model.services.count > 1 {
                    serviceList
                }
            }

            if model.showingIconPicker {
                Divider()
                iconPicker
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }

            if let message = model.message {
                Text(message)
                    .font(.system(size: 11))
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                    .textSelection(.enabled)
            }

            if model.showingSettings {
                Divider()
                settingsPanel
                    .transition(.opacity.combined(with: .move(edge: .top)))
            }

            Divider()
            footer
        }
        .padding(16)
        .frame(width: 360)
        .background(.regularMaterial)
    }

    private var header: some View {
        HStack(alignment: .firstTextBaseline) {
            Text("VPN Bar")
                .font(.system(size: 16, weight: .semibold))
            Spacer()
            Text(model.quickState.title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(statusColor)
        }
    }

    private var emptyState: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(L10n.text("vpn.empty.title"))
                .font(.system(size: 13, weight: .medium))
            Text(L10n.text("vpn.empty.hint"))
                .font(.system(size: 11))
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }

    private var quickControl: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(L10n.text(model.services.count > 1 ? "vpn.quick.title" : "vpn.single.title"))
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.secondary)

            if let service = model.quickService {
                Button {
                    model.toggle(service)
                } label: {
                    HStack(spacing: 10) {
                        VPNGlyph(icon: model.selectedIcon, size: 20, state: model.quickState)
                            .frame(width: 30, height: 28)
                        VStack(alignment: .leading, spacing: 2) {
                            Text(service.name)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(.primary)
                            Text(model.state(for: service).title)
                                .font(.system(size: 11))
                                .foregroundStyle(statusColor)
                        }
                        Spacer(minLength: 6)
                        Text(L10n.text(model.state(for: service) == .connected ? "action.disconnect" : "action.connect"))
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(statusColor)
                    }
                    .padding(.horizontal, 10)
                    .padding(.vertical, 9)
                    .background(Color.primary.opacity(0.055), in: RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)
                .contextMenu {
                    Button {
                        withAnimation(.easeInOut(duration: 0.18)) {
                            model.showingIconPicker = true
                        }
                    } label: {
                        Label(L10n.text("icon.change"), systemImage: "paintbrush")
                    }
                }
                .disabled(model.isWorking || model.state(for: service).isTransitioning)
            }
        }
    }

    private var serviceList: some View {
        VStack(alignment: .leading, spacing: 5) {
            Text(L10n.text("vpn.all.title"))
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(.secondary)

            ForEach(model.services) { service in
                let state = model.state(for: service)
                let rowTint = Color(nsColor: state.statusColor)
                HStack(spacing: 8) {
                    Button {
                        model.selectAndConnect(service)
                    } label: {
                        HStack(spacing: 8) {
                            Circle()
                                .fill(rowTint)
                                .frame(width: 7, height: 7)
                            VStack(alignment: .leading, spacing: 2) {
                                Text(service.name)
                                    .font(.system(size: 12, weight: .medium))
                                    .foregroundStyle(.primary)
                                Text(state.title)
                                    .font(.system(size: 10))
                                    .foregroundStyle(rowTint)
                            }
                            Spacer(minLength: 4)
                            if service.id == model.selectedServiceID {
                                Image(systemName: "checkmark")
                                    .font(.system(size: 10, weight: .semibold))
                                    .foregroundStyle(Color.accentColor)
                            }
                        }
                        .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)

                    Button {
                        model.toggle(service)
                    } label: {
                        Image(systemName: state == .connected ? "power" : "arrow.right")
                            .font(.system(size: 11, weight: .medium))
                            .foregroundStyle(rowTint)
                            .frame(width: 26, height: 26)
                            .contentShape(Rectangle())
                    }
                    .buttonStyle(.plain)
                    .help(L10n.format(
                        state == .connected ? "action.disconnect.named" : "action.connect.named",
                        service.name
                    ))
                    .disabled(model.isWorking || state.isTransitioning)
                }
                .padding(.horizontal, 8)
                .padding(.vertical, 5)
                .background(
                    service.id == model.selectedServiceID
                        ? Color.accentColor.opacity(0.08)
                        : Color.clear,
                    in: RoundedRectangle(cornerRadius: 8)
                )
            }
        }
    }

    private var iconPicker: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Text(L10n.text("icon.change"))
                    .font(.system(size: 11, weight: .medium))
                    .foregroundStyle(.secondary)
                Spacer()
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) {
                        model.showingIconPicker = false
                    }
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 10, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .frame(width: 24, height: 24)
                        .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .help(L10n.text("icon.closePicker"))
            }

            VStack(spacing: 5) {
                HStack(spacing: 6) {
                    ForEach(Array(VPNBarIcon.allCases.prefix(4))) { icon in
                        iconOption(icon)
                    }
                }
                HStack(spacing: 6) {
                    ForEach(Array(VPNBarIcon.allCases.suffix(3))) { icon in
                        iconOption(icon)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .center)
            }
        }
    }

    private var settingsPanel: some View {
        VStack(alignment: .leading, spacing: 7) {
            Toggle(L10n.text("settings.launchAtLogin"), isOn: $model.launchAtLoginEnabled)
            Toggle(L10n.text("settings.automaticReconnect"), isOn: $model.automaticReconnectEnabled)
            Text(L10n.text("settings.automaticReconnect.detail"))
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
            Toggle(L10n.text("settings.autoConnectWiFi"), isOn: $model.autoConnectOnWiFiEnabled)
            Text(L10n.text("settings.autoConnectWiFi.detail"))
                .font(.system(size: 10))
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .font(.system(size: 11))
        .toggleStyle(.switch)
    }

    private func iconOption(_ icon: VPNBarIcon) -> some View {
        let isSelected = model.selectedIcon == icon
        return Button {
            model.selectedIcon = icon
            withAnimation(.easeInOut(duration: 0.18)) {
                model.showingIconPicker = false
            }
        } label: {
            VPNGlyph(icon: icon, size: 22, state: model.quickState)
                .frame(width: 32, height: 32)
            .foregroundStyle(isSelected ? Color.accentColor : Color.primary)
            .frame(width: 56, height: 48)
            .background(
                isSelected ? Color.accentColor.opacity(0.12) : Color.clear,
                in: RoundedRectangle(cornerRadius: 8)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 8)
                    .strokeBorder(isSelected ? Color.accentColor.opacity(0.35) : Color.clear, lineWidth: 1)
            }
            .contentShape(RoundedRectangle(cornerRadius: 8))
        }
        .buttonStyle(.plain)
        .help(icon.title)
        .accessibilityLabel(L10n.format("icon.choose", icon.title))
        .accessibilityAddTraits(isSelected ? .isSelected : [])
    }

    private var footer: some View {
        HStack {
            Button(L10n.text("footer.refresh")) {
                model.clearMessage()
                model.refresh()
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)

            Spacer()

            Button {
                withAnimation(.easeInOut(duration: 0.18)) {
                    model.showingSettings.toggle()
                }
            } label: {
                Label(
                    L10n.text(model.showingSettings ? "settings.hide" : "settings.title"),
                    systemImage: "gearshape"
                )
            }
            .buttonStyle(.plain)
            .foregroundStyle(.secondary)

            Button(L10n.text("footer.quit"), action: onQuit)
                .buttonStyle(.plain)
                .foregroundStyle(.secondary)
        }
        .font(.system(size: 11))
    }
}
