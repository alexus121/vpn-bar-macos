import AppKit
import Foundation

@main
struct MakeVPNBarAppAssets {
    private static let iconSizes: [(type: String, pixels: Int)] = [
        ("icp4", 16),
        ("icp5", 32),
        ("icp6", 64),
        ("ic07", 128),
        ("ic08", 256),
        ("ic09", 512),
        ("ic10", 1024)
    ]

    private static let vectorIconNames = ["eye", "vpn", "lightning", "open-lock", "globe", "key"]
    private static let maximumRasterDimension = 512

    @MainActor
    static func main() throws {
        guard CommandLine.arguments.count == 4 else {
            throw NSError(
                domain: "VPNBar.AppAssets",
                code: 1,
                userInfo: [NSLocalizedDescriptionKey: "Usage: make-app-assets output.icns resources-directory generated-resources-directory"]
            )
        }

        let resourcesURL = URL(fileURLWithPath: CommandLine.arguments[2], isDirectory: true)
        let generatedURL = URL(fileURLWithPath: CommandLine.arguments[3], isDirectory: true)
        try FileManager.default.createDirectory(at: generatedURL, withIntermediateDirectories: true)

        let iconsDirectory = resourcesURL.appendingPathComponent("Icons", isDirectory: true)
        let lockSVG = iconsDirectory.appendingPathComponent("open-lock.svg")
        let appIcon = try makeIconFile(from: lockSVG)
        try appIcon.write(to: URL(fileURLWithPath: CommandLine.arguments[1]))

        for name in vectorIconNames {
            let sourceURL = iconsDirectory.appendingPathComponent("\(name).svg")
            let png = try rasterize(sourceURL: sourceURL, squareCanvas: false)
            try png.write(to: generatedURL.appendingPathComponent("icon-\(name).png"))
        }

        for name in ["monkey-connected", "monkey-disconnected"] {
            let sourceURL = resourcesURL.appendingPathComponent("\(name).svg")
            let png = try rasterize(sourceURL: sourceURL, squareCanvas: true)
            try png.write(to: generatedURL.appendingPathComponent("\(name).png"))
        }
    }

    @MainActor
    private static func makeIconFile(from lockSVG: URL) throws -> Data {
        var chunks = Data()
        for item in iconSizes {
            let png = try renderAppIconPNG(size: item.pixels, lockSVG: lockSVG)
            chunks.append(contentsOf: item.type.utf8)
            appendUInt32(UInt32(8 + png.count), to: &chunks)
            chunks.append(png)
        }

        var result = Data("icns".utf8)
        appendUInt32(UInt32(8 + chunks.count), to: &result)
        result.append(chunks)
        return result
    }

    @MainActor
    private static func renderAppIconPNG(size: Int, lockSVG: URL) throws -> Data {
        guard let lock = NSImage(contentsOf: lockSVG) else {
            throw assetError(2, "Could not load the supplied open-lock vector at \(lockSVG.path).")
        }
        guard let bitmap = makeBitmap(width: size, height: size),
              let context = NSGraphicsContext(bitmapImageRep: bitmap) else {
            throw assetError(3, "Could not create the app icon bitmap.")
        }

        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = context
        context.imageInterpolation = .high

        let side = CGFloat(size)
        let canvas = NSRect(x: 0, y: 0, width: side, height: side)

        let targetHeight = side * 0.7
        let scale = targetHeight / lock.size.height
        let drawnSize = NSSize(width: lock.size.width * scale, height: targetHeight)
        let lockRect = NSRect(
            x: (side - drawnSize.width) / 2,
            y: (side - drawnSize.height) / 2,
            width: drawnSize.width,
            height: drawnSize.height
        )
        lock.draw(in: lockRect, from: .zero, operation: .sourceOver, fraction: 1)
        NSColor(calibratedRed: 0.094, green: 0.012, blue: 0.165, alpha: 1).setFill()
        lockRect.fill(using: .sourceAtop)
        NSColor(calibratedRed: 0.955, green: 0.949, blue: 0.968, alpha: 1).setFill()
        canvas.fill(using: .destinationOver)

        NSGraphicsContext.restoreGraphicsState()
        return try pngData(from: bitmap, errorCode: 4, message: "Could not encode the app icon as PNG.")
    }

    @MainActor
    private static func rasterize(sourceURL: URL, squareCanvas: Bool) throws -> Data {
        guard let image = NSImage(contentsOf: sourceURL) else {
            throw assetError(5, "Could not load vector artwork at \(sourceURL.path).")
        }

        let sourceWidth = max(image.size.width, 1)
        let sourceHeight = max(image.size.height, 1)
        let maximum = CGFloat(maximumRasterDimension)
        let scale = maximum / max(sourceWidth, sourceHeight)
        let contentSize = NSSize(width: sourceWidth * scale, height: sourceHeight * scale)
        let outputWidth = squareCanvas ? maximumRasterDimension : max(1, Int(contentSize.width.rounded()))
        let outputHeight = squareCanvas ? maximumRasterDimension : max(1, Int(contentSize.height.rounded()))

        guard let bitmap = makeBitmap(width: outputWidth, height: outputHeight),
              let context = NSGraphicsContext(bitmapImageRep: bitmap) else {
            throw assetError(6, "Could not create the vector artwork bitmap for \(sourceURL.lastPathComponent).")
        }

        NSGraphicsContext.saveGraphicsState()
        NSGraphicsContext.current = context
        context.imageInterpolation = .high
        let canvas = NSRect(x: 0, y: 0, width: outputWidth, height: outputHeight)
        let drawSize = squareCanvas ? contentSize : NSSize(width: outputWidth, height: outputHeight)
        let drawRect = NSRect(
            x: (canvas.width - drawSize.width) / 2,
            y: (canvas.height - drawSize.height) / 2,
            width: drawSize.width,
            height: drawSize.height
        )
        image.draw(in: drawRect, from: .zero, operation: .sourceOver, fraction: 1)
        NSGraphicsContext.restoreGraphicsState()
        return try pngData(
            from: bitmap,
            errorCode: 7,
            message: "Could not encode \(sourceURL.lastPathComponent) as PNG."
        )
    }

    private static func makeBitmap(width: Int, height: Int) -> NSBitmapImageRep? {
        NSBitmapImageRep(
            bitmapDataPlanes: nil,
            pixelsWide: width,
            pixelsHigh: height,
            bitsPerSample: 8,
            samplesPerPixel: 4,
            hasAlpha: true,
            isPlanar: false,
            colorSpaceName: .deviceRGB,
            bytesPerRow: 0,
            bitsPerPixel: 0
        )
    }

    private static func pngData(from bitmap: NSBitmapImageRep, errorCode: Int, message: String) throws -> Data {
        guard let png = bitmap.representation(using: .png, properties: [:]) else {
            throw assetError(errorCode, message)
        }
        return png
    }

    private static func assetError(_ code: Int, _ message: String) -> NSError {
        NSError(domain: "VPNBar.AppAssets", code: code, userInfo: [NSLocalizedDescriptionKey: message])
    }

    private static func appendUInt32(_ value: UInt32, to data: inout Data) {
        var bigEndianValue = value.bigEndian
        withUnsafeBytes(of: &bigEndianValue) {
            data.append(contentsOf: $0)
        }
    }
}
