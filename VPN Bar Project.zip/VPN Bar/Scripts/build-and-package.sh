#!/bin/bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "$0")/.." && pwd)"
DIST_DIR="$ROOT_DIR/dist"
STAGING_DIR="$(mktemp -d /private/tmp/VPNBar.XXXXXX)"
BUILD_DIR="$STAGING_DIR/Build"
APP_BUNDLE="$STAGING_DIR/VPN Bar.app"
APP_RESOURCES="$APP_BUNDLE/Contents/Resources"
PACKAGE_ROOT="$STAGING_DIR/Package"
PACKAGE_APP="$PACKAGE_ROOT/VPN Bar.app"
COMPONENT_PACKAGE="$STAGING_DIR/VPNBarComponent.pkg"
PACKAGE_PATH="$STAGING_DIR/VPN Bar Installer.pkg"
APP_ARCHIVE="$STAGING_DIR/VPN Bar.app.zip"

cleanup() {
  rm -rf "$STAGING_DIR"
}
trap cleanup EXIT

cd "$ROOT_DIR"
mkdir -p "$BUILD_DIR/clang-module-cache"
mkdir -p "$DIST_DIR"
SDK_PATH="$(xcrun --sdk macosx --show-sdk-path)"

swiftc \
  -O \
  -parse-as-library \
  -target arm64-apple-macosx13.0 \
  -sdk "$SDK_PATH" \
  -module-cache-path "$BUILD_DIR/clang-module-cache" \
  -o "$BUILD_DIR/VPNBar-arm64" \
  "$ROOT_DIR"/Sources/VPNBar/*.swift

swiftc \
  -O \
  -parse-as-library \
  -target x86_64-apple-macosx13.0 \
  -sdk "$SDK_PATH" \
  -module-cache-path "$BUILD_DIR/clang-module-cache" \
  -o "$BUILD_DIR/VPNBar-x86_64" \
  "$ROOT_DIR"/Sources/VPNBar/*.swift

lipo -create "$BUILD_DIR/VPNBar-arm64" "$BUILD_DIR/VPNBar-x86_64" -output "$BUILD_DIR/VPNBar"

swiftc \
  -O \
  -parse-as-library \
  -sdk "$SDK_PATH" \
  -module-cache-path "$BUILD_DIR/clang-module-cache" \
  -o "$BUILD_DIR/make-app-assets" \
  "$ROOT_DIR/Scripts/make-app-icon.swift"
"$BUILD_DIR/make-app-assets" \
  "$STAGING_DIR/AppIcon.icns" \
  "$ROOT_DIR/Resources" \
  "$STAGING_DIR/GeneratedResources"
cp "$STAGING_DIR/AppIcon.icns" "$ROOT_DIR/Resources/AppIcon.icns"

mkdir -p "$APP_RESOURCES/Icons" "$APP_BUNDLE/Contents/MacOS"
cp "$BUILD_DIR/VPNBar" "$APP_BUNDLE/Contents/MacOS/VPNBar"
cp "$ROOT_DIR/Resources/Info.plist" "$APP_BUNDLE/Contents/Info.plist"
cp "$ROOT_DIR/Resources/AppIcon.icns" "$APP_RESOURCES/AppIcon.icns"
cp "$ROOT_DIR/Resources/monkey-connected.svg" "$APP_RESOURCES/monkey-connected.svg"
cp "$ROOT_DIR/Resources/monkey-disconnected.svg" "$APP_RESOURCES/monkey-disconnected.svg"
cp "$ROOT_DIR/Resources/Icons/"*.svg "$APP_RESOURCES/Icons/"
cp -R "$ROOT_DIR/Resources/en.lproj" "$ROOT_DIR/Resources/ru.lproj" "$APP_RESOURCES/"
cp "$STAGING_DIR/GeneratedResources/"*.png "$APP_RESOURCES/"

xattr -cr "$APP_BUNDLE"
codesign --force --deep --sign - --timestamp=none "$APP_BUNDLE"
xattr -cr "$APP_BUNDLE"
find "$APP_BUNDLE" -depth \( -name '._*' -o -name '.__*' \) -exec rm -rf {} +
codesign --verify --deep --strict "$APP_BUNDLE"

ditto -c -k --norsrc --keepParent "$APP_BUNDLE" "$APP_ARCHIVE"
mkdir -p "$PACKAGE_ROOT"
ditto --norsrc "$APP_BUNDLE" "$PACKAGE_APP"
codesign --verify --deep --strict "$PACKAGE_APP"

pkgbuild \
  --root "$PACKAGE_ROOT" \
  --install-location /Applications \
  --identifier com.alexus121.vpnbar.component \
  --version 1.1.0 \
  "$COMPONENT_PACKAGE"

productbuild --synthesize --package "$COMPONENT_PACKAGE" "$STAGING_DIR/Distribution.xml"
productbuild \
  --distribution "$STAGING_DIR/Distribution.xml" \
  --package-path "$STAGING_DIR" \
  --identifier com.alexus121.vpnbar \
  --version 1.1.0 \
  "$PACKAGE_PATH"

cp "$APP_ARCHIVE" "$DIST_DIR/VPN Bar.app.zip"
cp "$PACKAGE_PATH" "$DIST_DIR/VPN Bar Installer.pkg"

PROJECT_DIR="$STAGING_DIR/VPN Bar"
mkdir -p "$PROJECT_DIR"
cp -R "$ROOT_DIR/Sources" "$ROOT_DIR/Scripts" "$ROOT_DIR/Resources" "$ROOT_DIR/dist" "$PROJECT_DIR/"
cp "$ROOT_DIR/Package.swift" "$ROOT_DIR/README.md" "$ROOT_DIR/Install VPN Bar.command" \
  "$ROOT_DIR/.gitignore" \
  "$ROOT_DIR/vpn-connected-menu.png" "$ROOT_DIR/vpn-disconnected-menubar.png" \
  "$ROOT_DIR/vpn-menubar-full.png" "$PROJECT_DIR/"
ditto -c -k --norsrc --keepParent "$PROJECT_DIR" "$ROOT_DIR/VPN Bar Project.zip"

printf 'Created app archive: %s\n' "$DIST_DIR/VPN Bar.app.zip"
printf 'Created installer: %s\n' "$DIST_DIR/VPN Bar Installer.pkg"
printf 'Created project archive: %s\n' "$ROOT_DIR/VPN Bar Project.zip"
