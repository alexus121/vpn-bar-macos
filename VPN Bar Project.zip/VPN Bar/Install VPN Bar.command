#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_PATH="$SCRIPT_DIR/dist/VPN Bar Installer.pkg"

if [[ ! -f "$INSTALLER_PATH" ]]; then
  echo "Не найден установщик. Сначала запустите Scripts/build-and-package.sh."
  read -r -p "Нажмите Return для закрытия..."
  exit 1
fi

open "$INSTALLER_PATH"
