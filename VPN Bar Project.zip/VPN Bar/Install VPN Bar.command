#!/bin/bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
INSTALLER_PATH="$SCRIPT_DIR/dist/VPN Bar Installer.pkg"

if [[ ! -f "$INSTALLER_PATH" ]]; then
  FIRST_LANGUAGE="$(defaults read -g AppleLanguages 2>/dev/null | sed -n 's/^[[:space:]]*"\([^"]*\)".*/\1/p' | head -n 1 || true)"
  if [[ "$FIRST_LANGUAGE" == ru* ]]; then
    echo "Не найден установщик. Сначала запустите Scripts/build-and-package.sh."
    read -r -p "Нажмите Return для закрытия..."
  else
    echo "Installer not found. Run Scripts/build-and-package.sh first."
    read -r -p "Press Return to close..."
  fi
  exit 1
fi

open "$INSTALLER_PATH"
