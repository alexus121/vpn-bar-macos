// swift-tools-version: 5.9
import PackageDescription

let package = Package(
    name: "VPNBar",
    platforms: [.macOS(.v13)],
    products: [
        .executable(name: "VPNBar", targets: ["VPNBar"])
    ],
    targets: [
        .executableTarget(name: "VPNBar")
    ]
)
